import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var messageLabel: UILabel!
    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Events"
        let status = notificationsEnabled ? "on" : "off"
        messageLabel.text = "Welcome, \(studentName)! (\(selectedRole)) Notifications: \(status)."
    }
}
